import React, { useMemo, useState, useEffect } from 'react';
import { getBranches, getReviews, addBranch } from '../services/mockData';
import { Branch, AIAnalysisResult } from '../types';
import { StarRating } from '../components/StarRating';
import { 
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, 
    PieChart, Pie, Cell 
} from 'recharts';
import { analyzeReviewsWithGemini } from '../services/geminiService';
import { BrainCircuit, Loader2, ArrowUpRight, ArrowDownRight, MessageCircle, Plus, Store, X } from 'lucide-react';

const COLORS = ['#10b981', '#f59e0b', '#ef4444']; // Green, Amber, Red

export const AdminDashboard: React.FC = () => {
  const [selectedBranchId, setSelectedBranchId] = useState<string>('all');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<AIAnalysisResult | null>(null);
  
  // Branch Management State
  const [branches, setBranches] = useState<Branch[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [newBranchAddress, setNewBranchAddress] = useState('');
  const [addingBranch, setAddingBranch] = useState(false);
  const [forceUpdate, setForceUpdate] = useState(0); // Simple trigger to re-fetch data

  useEffect(() => {
    setBranches(getBranches());
  }, [forceUpdate, isModalOpen]);

  const reviews = useMemo(() => getReviews(selectedBranchId === 'all' ? undefined : selectedBranchId), [selectedBranchId, forceUpdate, branches]);

  // Statistics Calculation
  const stats = useMemo(() => {
    if (reviews.length === 0) return null;
    const total = reviews.length;
    const avg = reviews.reduce((acc, r) => acc + (r.foodRating + r.serviceRating + r.speedRating + r.cleanlinessRating) / 4, 0) / total;
    const positive = reviews.filter(r => ((r.foodRating + r.serviceRating) / 2) >= 4).length;
    const negative = reviews.filter(r => ((r.foodRating + r.serviceRating) / 2) <= 3).length;

    const catAvg = {
        food: reviews.reduce((acc, r) => acc + r.foodRating, 0) / total,
        service: reviews.reduce((acc, r) => acc + r.serviceRating, 0) / total,
        speed: reviews.reduce((acc, r) => acc + r.speedRating, 0) / total,
        cleanliness: reviews.reduce((acc, r) => acc + r.cleanlinessRating, 0) / total,
    };

    return { total, avg, positive, negative, catAvg };
  }, [reviews]);

  const handleAIAnalysis = async () => {
    setAiLoading(true);
    setAiResult(null);
    const result = await analyzeReviewsWithGemini(reviews);
    setAiResult(result);
    setAiLoading(false);
  };

  const handleAddBranch = async (e: React.FormEvent) => {
      e.preventDefault();
      setAddingBranch(true);
      await addBranch({
          name: newBranchName,
          address: newBranchAddress,
          telegramChatId: `@${newBranchName.replace(/\s+/g, '_').toLowerCase()}`
      });
      setNewBranchName('');
      setNewBranchAddress('');
      setIsModalOpen(false);
      setAddingBranch(false);
      setForceUpdate(prev => prev + 1); // Refresh UI
  };

  const pieData = stats ? [
    { name: 'Positive', value: stats.positive },
    { name: 'Neutral', value: stats.total - stats.positive - stats.negative },
    { name: 'Negative', value: stats.negative },
  ] : [];

  const barData = stats ? [
    { name: 'Food', score: stats.catAvg.food },
    { name: 'Service', score: stats.catAvg.service },
    { name: 'Speed', score: stats.catAvg.speed },
    { name: 'Clean', score: stats.catAvg.cleanliness },
  ] : [];

  if (branches.length === 0) {
      return (
          <div className="flex flex-col items-center justify-center h-[80vh] text-center space-y-4">
              <Store size={48} className="text-slate-300" />
              <h2 className="text-2xl font-bold text-slate-800">No Branches Found</h2>
              <p className="text-slate-500">It looks like you don't have any branches set up yet.</p>
              {/* This state is rare if coming from register, but good fallback */}
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-amber-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-amber-700 transition-colors"
              >
                  Create First Branch
              </button>
               {/* Modal for empty state */}
               {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-2xl">
                        <h2 className="text-2xl font-bold mb-6">Add New Branch</h2>
                        <form onSubmit={handleAddBranch} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Branch Name</label>
                                <input required type="text" value={newBranchName} onChange={e => setNewBranchName(e.target.value)} className="w-full p-3 border border-slate-300 rounded-lg" placeholder="e.g. Downtown Location" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                                <input required type="text" value={newBranchAddress} onChange={e => setNewBranchAddress(e.target.value)} className="w-full p-3 border border-slate-300 rounded-lg" placeholder="e.g. 123 Main St" />
                            </div>
                            <div className="flex justify-end space-x-3 mt-6">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
                                <button type="submit" disabled={addingBranch} className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700">{addingBranch ? 'Adding...' : 'Add Branch'}</button>
                            </div>
                        </form>
                    </div>
                </div>
              )}
          </div>
      );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h1 className="text-2xl font-bold text-slate-800">Analytics</h1>
            <p className="text-slate-500">Real-time performance overview</p>
        </div>
        <div className="flex items-center gap-3">
             <button 
                onClick={() => setIsModalOpen(true)}
                className="flex items-center space-x-2 bg-slate-900 text-white px-4 py-2.5 rounded-lg hover:bg-slate-800 transition-colors"
            >
                <Plus size={18} />
                <span>Add Branch</span>
            </button>

            <select 
                className="p-2.5 border border-slate-300 rounded-lg bg-white shadow-sm focus:ring-2 focus:ring-amber-500 focus:outline-none min-w-[200px]"
                value={selectedBranchId}
                onChange={(e) => { setSelectedBranchId(e.target.value); setAiResult(null); }}
            >
                <option value="all">All Branches</option>
                {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
        </div>
      </div>

      {/* KPI Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <KpiCard label="Total Reviews" value={stats.total} icon={<MessageCircle className="text-blue-500"/>} />
            <KpiCard label="Avg. Rating" value={stats.avg.toFixed(1)} subValue="/ 5.0" icon={<StarRating rating={stats.avg} size={16} readonly />} />
            <KpiCard label="Positive" value={`${((stats.positive / stats.total) * 100).toFixed(0)}%`} icon={<ArrowUpRight className="text-green-500" />} />
            <KpiCard label="Negative" value={`${((stats.negative / stats.total) * 100).toFixed(0)}%`} icon={<ArrowDownRight className="text-red-500" />} />
        </div>
      )}

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-w-0 flex flex-col">
            <h3 className="font-semibold text-slate-700 mb-4">Category Performance</h3>
            <div className="h-64 w-full relative flex-1 min-h-[250px]">
                {stats && (
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={barData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                            <XAxis type="number" domain={[0, 5]} hide />
                            <YAxis dataKey="name" type="category" width={80} tick={{fontSize: 12}} />
                            <RechartsTooltip cursor={{fill: 'transparent'}} />
                            <Bar dataKey="score" fill="#f59e0b" radius={[0, 4, 4, 0]} barSize={24} />
                        </BarChart>
                    </ResponsiveContainer>
                )}
            </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 min-w-0 flex flex-col">
            <h3 className="font-semibold text-slate-700 mb-4">Sentiment Distribution</h3>
            <div className="h-64 w-full relative flex-1 min-h-[250px]">
                {stats && (
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie 
                                data={pieData} 
                                cx="50%" 
                                cy="50%" 
                                innerRadius={60} 
                                outerRadius={80} 
                                paddingAngle={5} 
                                dataKey="value"
                            >
                                {pieData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <RechartsTooltip />
                            <Legend verticalAlign="bottom" height={36}/>
                        </PieChart>
                    </ResponsiveContainer>
                )}
            </div>
        </div>
      </div>

      {/* AI Section */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-xl p-6 text-white shadow-lg">
        <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-3">
                <BrainCircuit className="text-amber-400" size={28} />
                <div>
                    <h3 className="text-lg font-bold">Gemini AI Analysis</h3>
                    <p className="text-slate-400 text-sm">Analyze unstructured comments for insights</p>
                </div>
            </div>
            <button 
                onClick={handleAIAnalysis}
                disabled={aiLoading}
                className="bg-amber-500 hover:bg-amber-600 text-white px-4 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 flex items-center"
            >
                {aiLoading && <Loader2 className="animate-spin mr-2" size={18} />}
                {aiLoading ? 'Analyzing...' : 'Generate Report'}
            </button>
        </div>

        {aiResult && (
            <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-700 space-y-4 animate-in fade-in slide-in-from-bottom-4">
                <div className="flex items-center justify-between">
                    <span className="text-slate-300 font-mono text-sm">SENTIMENT: <span className="text-white font-bold">{aiResult.sentiment.toUpperCase()}</span></span>
                </div>
                <p className="text-slate-200 leading-relaxed">{aiResult.summary}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="bg-slate-900/50 p-4 rounded border-l-4 border-green-500">
                        <h4 className="font-bold text-green-400 mb-2">Top Pros</h4>
                        <ul className="list-disc list-inside text-sm text-slate-300">
                            {aiResult.topPros.map((p, i) => <li key={i}>{p}</li>)}
                        </ul>
                    </div>
                    <div className="bg-slate-900/50 p-4 rounded border-l-4 border-red-500">
                        <h4 className="font-bold text-red-400 mb-2">Top Cons</h4>
                        <ul className="list-disc list-inside text-sm text-slate-300">
                            {aiResult.topCons.map((c, i) => <li key={i}>{c}</li>)}
                        </ul>
                    </div>
                </div>
                 <div className="bg-amber-900/20 p-4 rounded border border-amber-500/30">
                        <h4 className="font-bold text-amber-400 mb-2">Actionable Insights</h4>
                        <ul className="list-disc list-inside text-sm text-slate-300">
                            {aiResult.actionableInsights.map((action, i) => <li key={i}>{action}</li>)}
                        </ul>
                    </div>
            </div>
        )}
      </div>

       {/* Add Branch Modal */}
       {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                        <Store size={20} className="text-amber-400" />
                        Add New Branch
                    </h2>
                    <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white transition-colors">
                        <X size={24} />
                    </button>
                </div>
                
                <form onSubmit={handleAddBranch} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Branch Name</label>
                        <input 
                            required 
                            type="text" 
                            value={newBranchName} 
                            onChange={e => setNewBranchName(e.target.value)} 
                            className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-shadow" 
                            placeholder="e.g. Westside Location" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                        <input 
                            required 
                            type="text" 
                            value={newBranchAddress} 
                            onChange={e => setNewBranchAddress(e.target.value)} 
                            className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none transition-shadow" 
                            placeholder="e.g. 456 Sunset Blvd" 
                        />
                    </div>
                    
                    <div className="bg-blue-50 p-3 rounded-lg text-xs text-blue-800 border border-blue-100">
                        <p>A Telegram Bot ID will be auto-generated for demo purposes.</p>
                    </div>

                    <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-slate-100">
                        <button 
                            type="button" 
                            onClick={() => setIsModalOpen(false)} 
                            className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            type="submit" 
                            disabled={addingBranch} 
                            className="px-6 py-2.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 font-bold shadow-lg shadow-amber-500/20 transition-all active:scale-95 disabled:opacity-70 disabled:active:scale-100 flex items-center gap-2"
                        >
                            {addingBranch ? <Loader2 className="animate-spin" size={18} /> : <Plus size={18} />}
                            {addingBranch ? 'Creating...' : 'Create Branch'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};

const KpiCard: React.FC<{ label: string; value: string | number; subValue?: string; icon: React.ReactNode }> = ({ label, value, subValue, icon }) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex flex-col justify-between">
        <div className="flex justify-between items-start mb-4">
            <span className="text-slate-500 font-medium text-sm">{label}</span>
            <div className="p-2 bg-slate-50 rounded-lg">{icon}</div>
        </div>
        <div className="flex items-baseline space-x-1">
            <span className="text-2xl font-bold text-slate-800">{value}</span>
            {subValue && <span className="text-sm text-slate-400">{subValue}</span>}
        </div>
    </div>
);