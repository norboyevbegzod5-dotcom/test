import React, { useState, useEffect, useMemo } from 'react';
import { getBranches, getReviews } from '../services/mockData';
import { Branch, Review } from '../types';
import { StarRating } from '../components/StarRating';
import { Filter, MessageSquare, Search, Calendar } from 'lucide-react';

export const ReviewsPage: React.FC = () => {
    const [selectedBranchId, setSelectedBranchId] = useState<string>('all');
    const [branches, setBranches] = useState<Branch[]>([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        setBranches(getBranches());
    }, []);

    const reviews = useMemo(() => {
        let data = getReviews(selectedBranchId === 'all' ? undefined : selectedBranchId);
        
        if (searchTerm) {
            const lowerTerm = searchTerm.toLowerCase();
            data = data.filter(r => 
                r.comment.toLowerCase().includes(lowerTerm) || 
                r.tableNumber?.toLowerCase().includes(lowerTerm)
            );
        }
        return data;
    }, [selectedBranchId, searchTerm, branches]);

    return (
        <div className="space-y-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">Customer Reviews</h1>
                    <p className="text-slate-500">Manage and respond to feedback</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                    <div className="relative group">
                        <Search className="absolute left-3 top-3 text-slate-400 group-focus-within:text-amber-500 transition-colors" size={18} />
                        <input 
                            type="text" 
                            placeholder="Search comments..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full sm:w-64 pl-10 pr-4 py-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none transition-all"
                        />
                    </div>
                    
                    <div className="relative">
                        <Filter className="absolute left-3 top-3 text-slate-400" size={18} />
                        <select 
                            className="w-full sm:w-auto pl-10 pr-8 py-2.5 border border-slate-300 rounded-lg bg-white appearance-none focus:ring-2 focus:ring-amber-500 focus:outline-none"
                            value={selectedBranchId}
                            onChange={(e) => setSelectedBranchId(e.target.value)}
                        >
                            <option value="all">All Branches</option>
                            {branches.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                        </select>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-slate-600">
                        <thead className="bg-slate-50 text-slate-800 font-medium border-b border-slate-200">
                            <tr>
                                <th className="px-6 py-4">Date</th>
                                <th className="px-6 py-4">Branch</th>
                                <th className="px-6 py-4">Table</th>
                                <th className="px-6 py-4 text-center">Food</th>
                                <th className="px-6 py-4 text-center">Service</th>
                                <th className="px-6 py-4 text-center">Speed</th>
                                <th className="px-6 py-4 text-center">Clean</th>
                                <th className="px-6 py-4 w-1/3">Comment</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {reviews.length > 0 ? (
                                reviews.map(review => (
                                    <tr key={review.id} className="hover:bg-slate-50 transition-colors">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center text-slate-500">
                                                <Calendar size={14} className="mr-2" />
                                                {new Date(review.timestamp).toLocaleDateString()}
                                            </div>
                                            <div className="text-xs text-slate-400 mt-1">
                                                {new Date(review.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 font-medium text-slate-800">
                                            {branches.find(b => b.id === review.branchId)?.name || 'Unknown'}
                                        </td>
                                        <td className="px-6 py-4 text-slate-500">
                                            {review.tableNumber ? `#${review.tableNumber}` : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <RatingBadge rating={review.foodRating} />
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <RatingBadge rating={review.serviceRating} />
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <RatingBadge rating={review.speedRating} />
                                        </td>
                                        <td className="px-6 py-4 text-center">
                                            <RatingBadge rating={review.cleanlinessRating} />
                                        </td>
                                        <td className="px-6 py-4">
                                            <p className="text-slate-700 leading-relaxed">{review.comment}</p>
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={8} className="px-6 py-12 text-center text-slate-500">
                                        <div className="flex flex-col items-center justify-center">
                                            <MessageSquare size={48} className="text-slate-300 mb-4" />
                                            <p className="text-lg font-medium">No reviews found</p>
                                            <p className="text-sm">Try adjusting your filters</p>
                                        </div>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

const RatingBadge: React.FC<{ rating: number }> = ({ rating }) => {
    let colorClass = 'bg-slate-100 text-slate-600';
    if (rating >= 4) colorClass = 'bg-green-100 text-green-700 border border-green-200';
    else if (rating <= 3) colorClass = 'bg-red-50 text-red-600 border border-red-100';
    else colorClass = 'bg-amber-50 text-amber-700 border border-amber-100';

    return (
        <span className={`inline-flex items-center justify-center px-2.5 py-1 rounded-md text-xs font-bold ${colorClass}`}>
            {rating.toFixed(1)}
        </span>
    );
};