import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UtensilsCrossed, CheckCircle, ArrowRight, Phone, Lock, User, Store, ShieldCheck, Loader2 } from 'lucide-react';
import { addBranch } from '../services/mockData';

type RegistrationStep = 'PHONE' | 'VERIFY' | 'DETAILS';

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<RegistrationStep>('PHONE');
  const [loading, setLoading] = useState(false);
  
  // Form State
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [restaurantName, setRestaurantName] = useState('');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');

  // Mock Request for OTP
  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setStep('VERIFY');
      alert(`Demo Code: 1234\n(In a real app, this would be sent to ${phoneNumber})`);
    }, 1500);
  };

  // Verify OTP
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
        setLoading(false);
        if (otp === '1234') {
            setStep('DETAILS');
        } else {
            alert('Invalid code. Please try 1234.');
        }
    }, 1000);
  };

  // Final Registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Add the FIRST branch automatically based on registration name
    await addBranch({
        name: restaurantName,
        address: 'Main Branch Location', // Default placeholder
        telegramChatId: `@${restaurantName.replace(/\s+/g, '_').toLowerCase()}_bot`
    });
    
    console.log("Registered user:", login);
    
    setLoading(false);
    navigate('/admin');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Left Side - Hero */}
      <div className="bg-slate-900 text-white md:w-1/2 p-12 flex flex-col justify-between relative overflow-hidden">
        <div className="z-10">
          <div className="flex items-center space-x-3 mb-8">
             <UtensilsCrossed className="text-amber-500" size={32} />
             <h1 className="text-2xl font-bold tracking-wider">RestoPulse</h1>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold leading-tight mb-6">
            Join the platform.
          </h2>
          <p className="text-slate-400 text-lg max-w-md">
            Secure, verified access for restaurant owners. Manage your reputation with ease.
          </p>
        </div>

        <div className="z-10 space-y-6 mt-12 md:mt-0">
           <StepIndicator active={step === 'PHONE' || step === 'VERIFY' || step === 'DETAILS'} label="Phone Verification" />
           <StepIndicator active={step === 'DETAILS'} label="Restaurant Details" />
           <StepIndicator active={false} label="Dashboard Access" />
        </div>

        {/* Decorative Background */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-600 rounded-full blur-[128px] opacity-20 -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600 rounded-full blur-[128px] opacity-20 translate-y-1/2 -translate-x-1/2"></div>
      </div>

      {/* Right Side - Form */}
      <div className="md:w-1/2 p-8 md:p-12 flex items-center justify-center">
        <div className="w-full max-w-md">
            
            {/* STEP 1: PHONE INPUT */}
            {step === 'PHONE' && (
                <div className="animate-in fade-in slide-in-from-right-8 duration-500">
                    <h3 className="text-3xl font-bold text-slate-900 mb-2">Get Started</h3>
                    <p className="text-slate-500 mb-8">Enter your mobile number to verify your account.</p>
                    <form onSubmit={handleRequestOtp} className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                            <div className="relative">
                                <Phone className="absolute left-3 top-3.5 text-slate-400" size={18} />
                                <input 
                                    required
                                    type="tel"
                                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                                    placeholder="+1 (555) 000-0000"
                                    value={phoneNumber}
                                    onChange={(e) => setPhoneNumber(e.target.value)}
                                />
                            </div>
                        </div>
                        <button
                            type="submit"
                            disabled={loading || phoneNumber.length < 5}
                            className="w-full bg-slate-900 text-white py-4 rounded-lg font-bold text-lg hover:bg-slate-800 transition-colors flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                            {loading ? <Loader2 className="animate-spin" /> : <span>Send Confirmation Code</span>}
                        </button>
                    </form>
                </div>
            )}

            {/* STEP 2: VERIFY OTP */}
            {step === 'VERIFY' && (
                <div className="animate-in fade-in slide-in-from-right-8 duration-500">
                    <button onClick={() => setStep('PHONE')} className="text-sm text-slate-500 hover:text-slate-800 mb-6 flex items-center">
                        ← Back to phone
                    </button>
                    <h3 className="text-3xl font-bold text-slate-900 mb-2">Verify Number</h3>
                    <p className="text-slate-500 mb-8">We sent a code to <span className="font-semibold text-slate-900">{phoneNumber}</span></p>
                    <form onSubmit={handleVerifyOtp} className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Confirmation Code (Use 1234)</label>
                            <div className="relative">
                                <ShieldCheck className="absolute left-3 top-3.5 text-slate-400" size={18} />
                                <input 
                                    required
                                    type="text"
                                    maxLength={4}
                                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none tracking-widest font-mono text-lg"
                                    placeholder="0000"
                                    value={otp}
                                    onChange={(e) => setOtp(e.target.value)}
                                />
                            </div>
                        </div>
                        <button
                            type="submit"
                            disabled={loading || otp.length !== 4}
                            className="w-full bg-slate-900 text-white py-4 rounded-lg font-bold text-lg hover:bg-slate-800 transition-colors flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                            {loading ? <Loader2 className="animate-spin" /> : <span>Verify Code</span>}
                        </button>
                    </form>
                </div>
            )}

            {/* STEP 3: DETAILS */}
            {step === 'DETAILS' && (
                <div className="animate-in fade-in slide-in-from-right-8 duration-500">
                     <div className="flex items-center space-x-2 text-green-600 mb-6 bg-green-50 p-3 rounded-lg w-fit">
                        <CheckCircle size={18} />
                        <span className="text-sm font-medium">Phone Verified</span>
                    </div>

                    <h3 className="text-3xl font-bold text-slate-900 mb-2">Account Details</h3>
                    <p className="text-slate-500 mb-8">Setup your restaurant profile and credentials.</p>
                    
                    <form onSubmit={handleRegister} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Restaurant Name</label>
                            <div className="relative">
                                <Store className="absolute left-3 top-3.5 text-slate-400" size={18} />
                                <input 
                                    required
                                    type="text"
                                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                                    placeholder="e.g. The Golden Spoon"
                                    value={restaurantName}
                                    onChange={(e) => setRestaurantName(e.target.value)}
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Create Login</label>
                            <div className="relative">
                                <User className="absolute left-3 top-3.5 text-slate-400" size={18} />
                                <input 
                                    required
                                    type="text"
                                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                                    placeholder="username"
                                    value={login}
                                    onChange={(e) => setLogin(e.target.value)}
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Create Password</label>
                            <div className="relative">
                                <Lock className="absolute left-3 top-3.5 text-slate-400" size={18} />
                                <input 
                                    required
                                    type="password"
                                    className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </div>
                        </div>

                        <div className="pt-4">
                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full bg-amber-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-amber-700 transition-colors flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 disabled:opacity-70"
                            >
                                {loading ? (
                                    <Loader2 className="animate-spin" />
                                ) : (
                                    <>
                                        <span>Complete Registration</span>
                                        <ArrowRight size={20} />
                                    </>
                                )}
                            </button>
                        </div>
                    </form>
                </div>
            )}
            
            <p className="text-center text-sm text-slate-500 mt-8">
                Already have an account? <a href="#" onClick={(e) => {e.preventDefault(); navigate('/admin')}} className="text-amber-600 font-semibold hover:underline">Log in</a>
            </p>
        </div>
      </div>
    </div>
  );
};

const StepIndicator: React.FC<{ active: boolean; label: string }> = ({ active, label }) => (
    <div className={`flex items-center space-x-4 transition-opacity duration-300 ${active ? 'opacity-100' : 'opacity-40'}`}>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${active ? 'bg-amber-500 text-slate-900 font-bold' : 'bg-slate-800 text-slate-500'}`}>
            {active ? <CheckCircle size={20} /> : <div className="w-3 h-3 bg-slate-600 rounded-full" />}
        </div>
        <p className="text-slate-300 font-medium">{label}</p>
    </div>
);
