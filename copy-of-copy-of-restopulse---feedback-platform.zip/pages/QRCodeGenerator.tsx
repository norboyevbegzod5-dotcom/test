import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { getBranches } from '../services/mockData';
import { Download } from 'lucide-react';

export const QRCodeGenerator: React.FC = () => {
    const branches = getBranches();
    const [selectedBranch, setSelectedBranch] = useState(branches[0].id);

    // In a real app, this would be the actual domain
    const baseUrl = `${window.location.origin}/#/review/${selectedBranch}`;

    const handleDownload = () => {
        const svg = document.getElementById("qr-code-svg");
        if (svg) {
            const svgData = new XMLSerializer().serializeToString(svg);
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");
            const img = new Image();
            img.onload = () => {
                canvas.width = img.width;
                canvas.height = img.height;
                ctx?.drawImage(img, 0, 0);
                const pngFile = canvas.toDataURL("image/png");
                const downloadLink = document.createElement("a");
                downloadLink.download = `QR-${selectedBranch}.png`;
                downloadLink.href = pngFile;
                downloadLink.click();
            };
            img.src = "data:image/svg+xml;base64," + btoa(svgData);
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6">
             <div>
                <h1 className="text-2xl font-bold text-slate-800">QR Code Manager</h1>
                <p className="text-slate-500">Generate and print codes for tables</p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-1 space-y-6 w-full">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">Select Branch</label>
                        <select 
                            value={selectedBranch}
                            onChange={(e) => setSelectedBranch(e.target.value)}
                            className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none"
                        >
                            {branches.map(b => (
                                <option key={b.id} value={b.id}>{b.name}</option>
                            ))}
                        </select>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg text-blue-800 text-sm">
                        <p className="font-semibold">Target URL:</p>
                        <p className="font-mono break-all">{baseUrl}</p>
                    </div>

                    <button 
                        onClick={handleDownload}
                        className="w-full flex items-center justify-center space-x-2 bg-slate-900 text-white py-3 rounded-lg hover:bg-slate-800 transition-colors"
                    >
                        <Download size={18} />
                        <span>Download PNG</span>
                    </button>
                </div>

                <div className="flex-shrink-0 bg-white p-4 border border-slate-100 rounded-xl shadow-inner flex flex-col items-center">
                    <QRCodeSVG 
                        id="qr-code-svg"
                        value={baseUrl}
                        size={256}
                        level={"H"}
                        includeMargin={true}
                    />
                    <p className="mt-4 font-bold text-slate-800">{branches.find(b => b.id === selectedBranch)?.name}</p>
                    <p className="text-xs text-slate-400 uppercase tracking-widest mt-1">Scan to Review</p>
                </div>
            </div>
        </div>
    );
};
