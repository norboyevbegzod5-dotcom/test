import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { StarRating } from '../components/StarRating';
import { getBranch, submitReview } from '../services/mockData';
import { Branch } from '../types';
import { Send, Upload, CheckCircle } from 'lucide-react';

export const FeedbackForm: React.FC = () => {
  const { branchId } = useParams<{ branchId: string }>();
  const [branch, setBranch] = useState<Branch | undefined>(undefined);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form State
  const [foodRating, setFoodRating] = useState(0);
  const [serviceRating, setServiceRating] = useState(0);
  const [speedRating, setSpeedRating] = useState(0);
  const [cleanlinessRating, setCleanlinessRating] = useState(0);
  const [comment, setComment] = useState('');
  const [tableNumber, setTableNumber] = useState('');

  useEffect(() => {
    if (branchId) {
      const data = getBranch(branchId);
      setBranch(data);
    }
  }, [branchId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchId) return;

    setLoading(true);
    await submitReview({
      branchId,
      foodRating,
      serviceRating,
      speedRating,
      cleanlinessRating,
      comment,
      tableNumber: tableNumber || undefined,
    });
    setLoading(false);
    setSubmitted(true);
  };

  if (!branch) {
    return (
      <div className="flex items-center justify-center min-h-screen text-slate-500">
        Loading branch info...
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full p-8 rounded-2xl shadow-xl text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Thank You!</h2>
          <p className="text-slate-600">
            Your feedback helps us improve. We've sent your review to the manager at <span className="font-semibold">{branch.name}</span>.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 py-6 px-4">
      <div className="max-w-lg mx-auto bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="bg-slate-900 p-6 text-white text-center">
          <h1 className="text-xl font-semibold opacity-90">Feedback for</h1>
          <h2 className="text-2xl font-bold mt-1">{branch.name}</h2>
          <p className="text-sm text-slate-400 mt-1">{branch.address}</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-amber-50 border border-amber-100 p-4 rounded-lg text-sm text-amber-800">
            How was your experience today? Please rate us below.
          </div>

          <div className="space-y-4">
            <StarRating rating={foodRating} setRating={setFoodRating} label="Food Quality" size={32} />
            <StarRating rating={serviceRating} setRating={setServiceRating} label="Service" size={32} />
            <StarRating rating={speedRating} setRating={setSpeedRating} label="Speed" size={32} />
            <StarRating rating={cleanlinessRating} setRating={setCleanlinessRating} label="Cleanliness" size={32} />
          </div>

          <div>
            <label className="block text-slate-700 font-medium mb-2">Comments</label>
            <textarea
              required
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none h-32 resize-none"
              placeholder="Tell us what you liked or how we can improve..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
               <label className="block text-slate-700 font-medium mb-2">Table No. (Optional)</label>
               <input 
                 type="text" 
                 value={tableNumber}
                 onChange={(e) => setTableNumber(e.target.value)}
                 className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
                 placeholder="e.g. 12"
               />
            </div>
             <div>
                <label className="block text-slate-700 font-medium mb-2">Photo (Optional)</label>
                <div className="w-full p-3 border border-slate-300 border-dashed rounded-lg flex items-center justify-center text-slate-400 cursor-pointer hover:bg-slate-50">
                    <Upload size={20} className="mr-2"/>
                    <span>Upload</span>
                </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || foodRating === 0}
            className={`w-full py-4 rounded-xl text-white font-bold text-lg flex items-center justify-center space-x-2 shadow-lg transition-all ${
              loading || foodRating === 0
                ? 'bg-slate-300 cursor-not-allowed'
                : 'bg-amber-600 hover:bg-amber-700 hover:shadow-amber-500/25 active:scale-98'
            }`}
          >
            {loading ? (
              <span>Sending...</span>
            ) : (
              <>
                <span>Submit Feedback</span>
                <Send size={20} />
              </>
            )}
          </button>
        </form>
      </div>
      <p className="text-center text-slate-400 text-xs mt-6">Powered by RestoPulse</p>
    </div>
  );
};
