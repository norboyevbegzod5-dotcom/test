import React, { useState, useEffect } from 'react';
import { getBranches, updateBranch } from '../services/mockData';
import { Branch } from '../types';
import { Store, MapPin, MessageCircle, Copy, Settings, Save, X, Bot } from 'lucide-react';

export const BranchesPage: React.FC = () => {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);

  useEffect(() => {
    setBranches(getBranches());
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const handleEditClick = (branch: Branch) => {
      setEditingBranch({ ...branch });
  };

  const handleSave = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!editingBranch) return;

      await updateBranch(editingBranch.id, {
          name: editingBranch.name,
          address: editingBranch.address,
          telegramChatId: editingBranch.telegramChatId,
          telegramBotToken: editingBranch.telegramBotToken
      });

      setBranches(getBranches()); // Refresh list
      setEditingBranch(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
            <h1 className="text-2xl font-bold text-slate-800">Branches</h1>
            <p className="text-slate-500">Manage your restaurant locations and Telegram connections</p>
        </div>
      </div>

      {branches.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-slate-200 shadow-sm">
            <Store size={48} className="mx-auto text-slate-300 mb-4" />
            <h3 className="text-lg font-medium text-slate-900">No Branches Yet</h3>
            <p className="text-slate-500">Add a branch from the Analytics Dashboard to see it here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {branches.map((branch) => (
            <div key={branch.id} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow flex flex-col">
                <div className="p-6 flex-1">
                    <div className="flex items-start justify-between mb-6">
                        <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 flex-shrink-0">
                                <Store size={24} />
                            </div>
                            <div>
                                <h3 className="font-bold text-lg text-slate-900 leading-tight">{branch.name}</h3>
                                <span className="text-xs font-mono text-slate-400">ID: {branch.id}</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => handleEditClick(branch)}
                            className="text-slate-400 hover:text-slate-700 transition-colors p-1"
                        >
                            <Settings size={20} />
                        </button>
                    </div>

                    <div className="space-y-4">
                        <div className="flex items-start space-x-3">
                            <MapPin size={18} className="text-slate-400 mt-0.5 flex-shrink-0" />
                            <div>
                                <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Address</p>
                                <p className="text-slate-700">{branch.address}</p>
                            </div>
                        </div>

                        <div className="flex items-start space-x-3">
                            <MessageCircle size={18} className="text-blue-500 mt-0.5 flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                                <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Telegram Chat ID</p>
                                <div 
                                    className="flex items-center justify-between bg-slate-50 rounded border border-slate-200 px-2 py-1 mt-1 cursor-pointer hover:bg-slate-100 group"
                                    onClick={() => copyToClipboard(branch.telegramChatId)}
                                    title="Click to copy"
                                >
                                    <p className="text-sm font-mono text-slate-700 truncate">{branch.telegramChatId}</p>
                                    <Copy size={12} className="text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                        </div>
                        
                        {branch.telegramBotToken && (
                             <div className="flex items-start space-x-3">
                                <Bot size={18} className="text-slate-400 mt-0.5 flex-shrink-0" />
                                <div className="flex-1">
                                    <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Bot Status</p>
                                    <span className="inline-flex items-center text-xs text-green-600 font-medium mt-1">
                                        <span className="w-2 h-2 bg-green-500 rounded-full mr-1.5"></span>
                                        Token Configured
                                    </span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-between items-center text-sm">
                    <span className="text-slate-500">
                        Active
                    </span>
                    <a href={`#/review/${branch.id}`} target="_blank" rel="noreferrer" className="text-amber-600 hover:text-amber-700 font-medium hover:underline">
                        View Form
                    </a>
                </div>
            </div>
            ))}
        </div>
      )}

      {/* Edit Modal */}
      {editingBranch && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="bg-slate-900 px-6 py-4 flex justify-between items-center text-white">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                        <Settings size={20} className="text-amber-400" />
                        Edit Branch Settings
                    </h2>
                    <button onClick={() => setEditingBranch(null)} className="text-slate-400 hover:text-white transition-colors">
                        <X size={24} />
                    </button>
                </div>
                
                <form onSubmit={handleSave} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Branch Name</label>
                        <input 
                            required 
                            type="text" 
                            value={editingBranch.name} 
                            onChange={e => setEditingBranch({...editingBranch, name: e.target.value})} 
                            className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" 
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                        <input 
                            required 
                            type="text" 
                            value={editingBranch.address} 
                            onChange={e => setEditingBranch({...editingBranch, address: e.target.value})} 
                            className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 outline-none" 
                        />
                    </div>

                    <div className="pt-4 border-t border-slate-100">
                        <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
                            <MessageCircle size={16} className="text-blue-500"/>
                            Telegram Integration
                        </h3>
                        
                        <div className="space-y-3">
                             <div>
                                <label className="block text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">Telegram Chat ID</label>
                                <input 
                                    required 
                                    type="text" 
                                    value={editingBranch.telegramChatId} 
                                    onChange={e => setEditingBranch({...editingBranch, telegramChatId: e.target.value})} 
                                    className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm" 
                                    placeholder="-100xxxxxxxxxx"
                                />
                                <p className="text-xs text-slate-400 mt-1">The Chat ID of the group/channel where reviews should be sent.</p>
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">Bot Token</label>
                                <input 
                                    type="password" 
                                    value={editingBranch.telegramBotToken || ''} 
                                    onChange={e => setEditingBranch({...editingBranch, telegramBotToken: e.target.value})} 
                                    className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm" 
                                    placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                                />
                                <p className="text-xs text-slate-400 mt-1">Required to send messages. Get this from @BotFather.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-slate-100">
                        <button 
                            type="button" 
                            onClick={() => setEditingBranch(null)} 
                            className="px-5 py-2.5 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            type="submit" 
                            className="px-6 py-2.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 font-bold shadow-lg shadow-amber-500/20 transition-all active:scale-95 flex items-center gap-2"
                        >
                            <Save size={18} />
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};