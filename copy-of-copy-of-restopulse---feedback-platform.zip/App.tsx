import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { FeedbackForm } from './pages/FeedbackForm';
import { AdminDashboard } from './pages/AdminDashboard';
import { QRCodeGenerator } from './pages/QRCodeGenerator';
import { Register } from './pages/Register';
import { ReviewsPage } from './pages/ReviewsPage';
import { BranchesPage } from './pages/BranchesPage';

// A simple wrapper to separate Admin Layout from Public Layout
const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <Layout isAdmin={true}>{children}</Layout>
);

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        {/* Main Entry Point: Registration */}
        <Route path="/" element={<Register />} />
        
        {/* Public Feedback Route */}
        <Route path="/review/:branchId" element={<FeedbackForm />} />
        
        {/* Admin Routes (Protected) */}
        <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
        <Route path="/admin/branches" element={<AdminRoute><BranchesPage /></AdminRoute>} />
        <Route path="/admin/reviews" element={<AdminRoute><ReviewsPage /></AdminRoute>} />
        <Route path="/qr-generator" element={<AdminRoute><QRCodeGenerator /></AdminRoute>} />
        
        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

export default App;