import { Branch, Review } from '../types';
import { sendTelegramNotification } from './telegramService';

let branches: Branch[] = [];
let storedReviews: Review[] = [];

// Helper to generate random past reviews for a specific branch
const generateMockReviewsForBranch = (branchId: string): Review[] => {
  const reviews: Review[] = [];
  const now = Date.now();
  const day = 86400000;

  for (let i = 0; i < 25; i++) {
    const isGood = Math.random() > 0.25; // 75% chance of good review
    reviews.push({
      id: `r-${branchId}-${i}-${Date.now()}`,
      branchId: branchId,
      foodRating: isGood ? 4 + Math.random() : 1 + Math.random() * 3,
      serviceRating: isGood ? 4 + Math.random() : 1 + Math.random() * 3,
      speedRating: isGood ? 5 : 2 + Math.random() * 2,
      cleanlinessRating: 4 + Math.random(),
      comment: isGood 
        ? ["Great food!", "Lovely atmosphere.", "Will come again.", "Tasty burger.", "Friendly staff."][Math.floor(Math.random() * 5)] 
        : ["Service was slow.", "Food was cold.", "Table was dirty.", "Too noisy.", "Waiter was rude."][Math.floor(Math.random() * 5)],
      timestamp: now - Math.floor(Math.random() * 30) * day,
      tableNumber: Math.floor(Math.random() * 20).toString(),
    });
  }
  return reviews;
};

export const getBranches = (): Branch[] => branches;

export const getBranch = (id: string): Branch | undefined => branches.find(b => b.id === id);

export const addBranch = (branchData: Omit<Branch, 'id'>): Promise<Branch> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const newBranch: Branch = {
        id: `b${Date.now()}`,
        ...branchData
      };
      branches = [...branches, newBranch];
      
      // Generate historical data for this new branch so the dashboard looks alive
      const newReviews = generateMockReviewsForBranch(newBranch.id);
      storedReviews = [...storedReviews, ...newReviews];
      
      resolve(newBranch);
    }, 500);
  });
};

export const updateBranch = (branchId: string, updates: Partial<Branch>): Promise<void> => {
    return new Promise((resolve) => {
        branches = branches.map(b => b.id === branchId ? { ...b, ...updates } : b);
        resolve();
    });
};

export const getReviews = (branchId?: string): Review[] => {
  if (branchId) {
    return storedReviews.filter(r => r.branchId === branchId).sort((a, b) => b.timestamp - a.timestamp);
  }
  return storedReviews.sort((a, b) => b.timestamp - a.timestamp);
};

export const submitReview = async (reviewData: Omit<Review, 'id' | 'timestamp'>): Promise<void> => {
    // 1. Create Review Object
    const newReview: Review = {
        ...reviewData,
        id: `new-${Date.now()}`,
        timestamp: Date.now(),
    };
    
    // 2. Save to "Database"
    storedReviews = [newReview, ...storedReviews];
    
    // 3. Trigger Telegram Notification
    const branch = getBranch(reviewData.branchId);
    if (branch) {
        await sendTelegramNotification(branch, newReview);
    }

    return Promise.resolve();
};