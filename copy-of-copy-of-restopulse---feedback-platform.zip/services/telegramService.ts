import { Review, Branch } from "../types";

const TELEGRAM_API_BASE = "https://api.telegram.org/bot";

export const sendTelegramNotification = async (branch: Branch, review: Review) => {
  if (!branch.telegramBotToken || !branch.telegramChatId) {
    console.warn("Telegram notification skipped: Missing Bot Token or Chat ID for branch", branch.name);
    return;
  }

  // 1. Calculate Average Rating for Visual Indicator
  const avgRating = (review.foodRating + review.serviceRating + review.speedRating + review.cleanlinessRating) / 4;
  
  // 2. Determine Status Icon based on requirements
  // Green mark if rating > 4, Red mark if rating <= 3
  let statusIcon = "🟡"; // Default neutral
  if (avgRating > 4) statusIcon = "🟢";
  else if (avgRating <= 3) statusIcon = "🔴";

  // 3. Format the Message (Markdown)
  const messageText = `
${statusIcon} *New Feedback Received*

📍 *Branch:* ${branch.name}
⭐ *Rating:* ${avgRating.toFixed(1)} / 5.0

🍽 Food: ${review.foodRating}
waiter Service: ${review.serviceRating}
⚡ Speed: ${review.speedRating}
✨ Cleanliness: ${review.cleanlinessRating}

💬 *Comment:*
_${review.comment || "No comment provided"}_

${review.tableNumber ? `🪑 *Table:* ${review.tableNumber}` : ""}
  `.trim();

  try {
    // 4. Send Request (Photo or Text)
    // Note: In a real environment, if photoUrl is a local blob, we'd need to send FormData.
    // For this demo, we assume if photoUrl is present, it's a URL, or we fail gracefully back to text.

    let endpoint = "sendMessage";
    const body: any = {
      chat_id: branch.telegramChatId,
      parse_mode: "Markdown",
    };

    if (review.photoUrl && !review.photoUrl.startsWith("blob:")) {
        // If it's a real URL (not a local blob), send as photo
        endpoint = "sendPhoto";
        body.photo = review.photoUrl;
        body.caption = messageText;
    } else {
        // Default to text message
        body.text = messageText;
    }

    console.log(`[Telegram Service] Sending to ${branch.telegramChatId} via ${endpoint}...`);

    const response = await fetch(`${TELEGRAM_API_BASE}${branch.telegramBotToken}/${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();
    if (!data.ok) {
        console.error("Telegram API Error:", data);
        throw new Error(data.description);
    }
    
    console.log("[Telegram Service] Notification Sent Successfully!");

  } catch (error) {
    console.error("[Telegram Service] Failed to send notification:", error);
    // We don't block the UI flow if Telegram fails, just log it.
  }
};
