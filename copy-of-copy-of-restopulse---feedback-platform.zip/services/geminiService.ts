import { GoogleGenAI, Type } from "@google/genai";
import { Review, AIAnalysisResult } from "../types";

// Note: Using the client-side API key for demonstration.
// In a production app, this should be proxied through a backend.
const getClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        console.warn("API Key not found in environment variables");
        return null;
    }
    return new GoogleGenAI({ apiKey });
};

export const analyzeReviewsWithGemini = async (reviews: Review[]): Promise<AIAnalysisResult | null> => {
    const ai = getClient();
    if (!ai || reviews.length === 0) return null;

    // Limit to last 20 reviews to avoid token limits in this demo
    const recentComments = reviews
        .slice(0, 20)
        .map(r => `Review (Food: ${Math.round(r.foodRating)}/5): "${r.comment}"`)
        .join("\n");

    const prompt = `
        Analyze the following restaurant customer feedback and provide a structured summary.
        
        Feedback Data:
        ${recentComments}
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        sentiment: { type: Type.STRING, enum: ["Positive", "Neutral", "Negative"] },
                        summary: { type: Type.STRING },
                        topPros: { type: Type.ARRAY, items: { type: Type.STRING } },
                        topCons: { type: Type.ARRAY, items: { type: Type.STRING } },
                        actionableInsights: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                }
            }
        });

        if (response.text) {
            return JSON.parse(response.text) as AIAnalysisResult;
        }
        return null;

    } catch (error) {
        console.error("Gemini Analysis Error:", error);
        return null;
    }
};
