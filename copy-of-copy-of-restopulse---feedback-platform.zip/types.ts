export interface Branch {
  id: string;
  name: string;
  address: string;
  telegramChatId: string;
  telegramBotToken?: string; // Optional: specific bot per branch, or global
}

export interface Review {
  id: string;
  branchId: string;
  foodRating: number;
  serviceRating: number;
  speedRating: number;
  cleanlinessRating: number;
  comment: string;
  tableNumber?: string;
  timestamp: number;
  photoUrl?: string; // Placeholder for uploaded photo
}

export interface BranchStats {
  totalReviews: number;
  averageRating: number;
  positivePercentage: number;
  negativePercentage: number;
  categoryAverages: {
    food: number;
    service: number;
    speed: number;
    cleanliness: number;
  };
}

export interface AIAnalysisResult {
  sentiment: 'Positive' | 'Neutral' | 'Negative';
  summary: string;
  topPros: string[];
  topCons: string[];
  actionableInsights: string[];
}