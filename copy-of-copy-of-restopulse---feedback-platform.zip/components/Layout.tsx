import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, QrCode, MessageSquare, UtensilsCrossed, Store } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  isAdmin?: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, isAdmin = false }) => {
  if (!isAdmin) {
    return <div className="min-h-screen bg-slate-50">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-slate-900 text-white p-6 flex-shrink-0">
        <div className="flex items-center space-x-3 mb-10">
            <UtensilsCrossed className="text-amber-500" size={28} />
            <h1 className="text-xl font-bold tracking-wider">RestoPulse</h1>
        </div>
        
        <nav className="space-y-2">
            <NavItem to="/admin" icon={<LayoutDashboard size={20} />} label="Analytics" />
            <NavItem to="/admin/branches" icon={<Store size={20} />} label="Branches" />
            <NavItem to="/admin/reviews" icon={<MessageSquare size={20} />} label="All Reviews" />
            <NavItem to="/qr-generator" icon={<QrCode size={20} />} label="QR Codes" />
        </nav>

        <div className="mt-auto pt-10 text-slate-500 text-xs">
            <p>Admin Panel v1.0</p>
            <p className="mt-1">Head Office View</p>
        </div>
      </aside>
      
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
};

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string }> = ({ to, icon, label }) => (
    <NavLink 
        to={to} 
        end={to === '/admin'} 
        className={({ isActive }) => 
            `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                isActive ? 'bg-amber-600 text-white' : 'text-slate-300 hover:bg-slate-800'
            }`
        }
    >
        {icon}
        <span>{label}</span>
    </NavLink>
);