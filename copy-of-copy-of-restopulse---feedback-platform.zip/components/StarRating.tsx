import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  setRating?: (rating: number) => void;
  label?: string;
  readonly?: boolean;
  size?: number;
}

export const StarRating: React.FC<StarRatingProps> = ({ 
  rating, 
  setRating, 
  label, 
  readonly = false,
  size = 24
}) => {
  return (
    <div className="flex flex-col mb-4">
      {label && <label className="mb-2 font-medium text-slate-700">{label}</label>}
      <div className="flex space-x-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            disabled={readonly}
            onClick={() => setRating && setRating(star)}
            className={`transition-transform ${!readonly && 'hover:scale-110 active:scale-95'}`}
          >
            <Star
              size={size}
              className={`${
                star <= rating
                  ? 'fill-amber-400 text-amber-400'
                  : 'text-slate-300'
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );
};
